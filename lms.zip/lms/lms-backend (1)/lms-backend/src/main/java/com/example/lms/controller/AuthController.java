package com.example.lms.controller;

import com.example.lms.payload.LoginRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    // LOGIN API - accept any username and password
    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {
        // Ignore actual credentials
        return "Login successful! ✅";
    }
}
